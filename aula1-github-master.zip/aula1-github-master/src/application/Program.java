package application;

public class Program {

	public static void main(String[] args) {

		System.out.println("Bom dia!");
		System.out.println("Boa tarde!");
		System.out.println("Boa noite!");
	}
}
